return {
    descriptions={
        Joker={
            j_blueprint={
                name="Blueprint",
                text={
                    "Copies ability of",
                    "{C:attention}Joker{} to the right.",
                    "{C:attention}Brainstorms{} girlfriend",
                },
                unlock={
                    "Win a run",
                },
            },
            j_brainstorm={
                name="Brainstorm",
                text={
                    "Copies the ability",
                    "of leftmost {C:attention}Joker.",
                    "{C:attention}Blueprints{} girlfriend",
                },
                unlock={
                    "Discard a",
                    "{E:1,C:attention}Royal Flush",
                },
            },
        },
}
}
